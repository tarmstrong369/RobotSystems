Robot Hat
=======================
Library for Robot Hat
